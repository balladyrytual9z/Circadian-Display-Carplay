

# Integracja Circadian Display ↔ Dock 2.0 (CarPlay Launcher) — Android 9 (API 28)

## Kontrakt API (musi być zgodny z `CircadianBridge` w Docku)

| Element | Wartość |
|--------|---------|
| Package Circadian | `com.circadiandisplay.app` |
| Authority | `com.circadiandisplay.app.state` |
| Broadcast akcja | `pl.dock.widget.NIGHT_MODE_CHANGED` |
| Extra | `isNight` (boolean) |

### ContentProvider.call

| method | extras | wynik |
|--------|--------|--------|
| `activate_for_night` | – | `ok` (boolean) – włącza Circadian i od razu ewaluuje krzywą |
| `set_night_mode` | `isNight` | `ok` – night→enable, day→disable + clear |
| `get_status` | – | `ok`, `enabled`, `isNight`, `mode` |

**Zaufani callerzy (control methods):**  
`pl.dock.widget`, `pl.dock.launcher`, oraz własny UID / package aplikacji Circadian.  
Niezaufane wywołanie → `SecurityException` (Dock **musi** to złapać).

`get_status` nie wymaga zaufanego callera (tylko odczyt).

---

## Co jest w projekcie Circadian

1. Pliki:
   - `app/src/main/java/com/circadiandisplay/app/dock/DockStateProvider.kt`
   - `app/src/main/java/com/circadiandisplay/app/dock/DockNightModeReceiver.kt`

2. W `AndroidManifest.xml` (wewnątrz `<application>`):

```xml
<provider
    android:name=".dock.DockStateProvider"
    android:authorities="com.circadiandisplay.app.state"
    android:exported="true"
    android:grantUriPermissions="false" />

<receiver
    android:name=".dock.DockNightModeReceiver"
    android:exported="false">
    <intent-filter>
        <action android:name="pl.dock.widget.NIGHT_MODE_CHANGED" />
    </intent-filter>
</receiver>
```

3. `AppSettings`:
   - `suspend fun setEnabled(enabled: Boolean)`
   - `suspend fun isEnabledSnapshot(): Boolean`

4. `SchedulerWorker.triggerNow(Context)` — publiczna metoda, enqueue one-shot work.

---

## Wymagania po stronie Dock 2.0 (Android 9)

Instrukcja techniczna dla launchera (stabilność IPC na jednostkach samochodowych).

### 1. Autoryzacja w ContentProvider Docka (`pl.dock.widget.state`)

Jeśli Circadian odpytuje Dock (np. status), Dock musi akceptować pakiet Circadian:

```java
private boolean isCallerTrusted() {
    String callingPackage = getCallingPackage();
    return "pl.dock.launcher".equals(callingPackage)
        || "pl.dock.widget".equals(callingPackage)
        || "com.circadiandisplay.app".equals(callingPackage);
}
```

Niezaufane → log + `throw new SecurityException("Caller not trusted")`.

### 2. Asynchroniczna komunikacja w `CircadianBridge`

Wywołania `ContentResolver.call` **nie** na UI thread — dedykowany single-thread executor, żeby uniknąć jank / ANR na Android 9:

```java
private static final ExecutorService ipcExecutor = Executors.newSingleThreadExecutor();

public static void setNightMode(Context context, boolean isNight) {
    if (!isInstalled(context)) return;
    ipcExecutor.execute(() -> {
        try {
            Uri uri = Uri.parse("content://com.circadiandisplay.app.state");
            Bundle bundle = new Bundle();
            bundle.putBoolean("isNight", isNight);
            context.getContentResolver().call(uri, "set_night_mode", null, bundle);
        } catch (Exception e) {
            Log.e("CircadianBridge", "Błąd IPC: " + e.getMessage());
        }
    });
}
```

Metody: `set_night_mode`, `activate_for_night`, `get_status` (nie `setTheme` / `getState`).

### 3. Try-catch po stronie Docka

Otoczyć IPC: `SecurityException`, `IllegalArgumentException`, ogólne `Exception`.  
Force-stop Circadian **nie** może crashować Docka.

### 4. Testy na urządzeniu

- Force Stop Circadian → zmiana motywu w Docku → brak FATAL EXCEPTION.
- `adb logcat | grep -iE "Circadian|DockState|DockProvider|Caller not trusted"`
- Szybkie przełączanie day/night — UI Docka płynny (IPC w tle).

---

## Zachowanie w Docku

- `Prefs.circadianAuto` (domyślnie `true`)
- Przy zmianie wyglądu day/night: `CircadianBridge.setNightMode(ctx, night)`
- Przy `isNight=true`: `activate_for_night` / broadcast `NIGHT_MODE_CHANGED`

Wbudowany Night Shift Docka działa niezależnie.

## Build / release

Workflow `.github/workflows/build-release.yml` — debug APK + GitHub Release `v1.0.<run_number>`.


