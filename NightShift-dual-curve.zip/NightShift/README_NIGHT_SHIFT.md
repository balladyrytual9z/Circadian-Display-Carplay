
# Night Shift (based on Circadian Display 1.0.5 + Dock IPC)

Simplified iOS-style Night Shift for Android with:
- Manual toggle "until tomorrow"
- Schedule (From–To)
- Global color temperature slider
- Hardware white calibration (blue reduction)
- Auto NATIVE mode with OVERLAY fallback
- Bidirectional IPC with Dock 2.0 (`pl.dock.widget.NIGHT_MODE_CHANGED`)

Package: `com.circadiandisplay.app`

## Build

```bash
./gradlew :app:assembleDebug
```

Requires JDK 17 + Android SDK.

See `NIGHT_SHIFT_CHANGES.md` for the Prompt 1 change list.

