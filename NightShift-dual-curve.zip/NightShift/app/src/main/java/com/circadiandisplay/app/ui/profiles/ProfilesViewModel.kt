package com.circadiandisplay.app.ui.profiles

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.circadiandisplay.app.data.repository.CurveRepository
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.scheduler.SchedulerWorker
import com.circadiandisplay.core.curve.CurveProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One-shot navigation event emitted from [ProfilesViewModel]. */
sealed interface ProfilesEvent {
    data class OpenEditor(val profileId: Long) : ProfilesEvent
}

@HiltViewModel
class ProfilesViewModel
    @Inject
    constructor(
        private val application: Application,
        private val curveRepository: CurveRepository,
        private val appSettings: AppSettings,
    ) : ViewModel() {
        val uiState: StateFlow<ProfilesUiState> =
            combine(
                curveRepository.getAllProfiles(),
                appSettings.eveningProfileId,
                appSettings.nightProfileId,
            ) { profiles, eveningId, nightId ->
                ProfilesUiState(
                    isLoading = false,
                    profiles = profiles,
                    eveningProfileId = eveningId,
                    nightProfileId = nightId,
                )
            }.stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = ProfilesUiState(),
            )

        private val _events = MutableSharedFlow<ProfilesEvent>(extraBufferCapacity = 1)
        val events = _events.asSharedFlow()

        fun createProfile(name: String) {
            val trimmed = name.trim()
            if (trimmed.isEmpty()) return
            viewModelScope.launch {
                val id = curveRepository.insertProfile(CurveProfile(name = trimmed))
                _events.emit(ProfilesEvent.OpenEditor(id))
            }
        }

        fun setAsEvening(id: Long) {
            viewModelScope.launch {
                appSettings.setEveningProfileId(id)
                SchedulerWorker.triggerNow(application)
            }
        }

        fun setAsNight(id: Long) {
            viewModelScope.launch {
                appSettings.setNightProfileId(id)
                SchedulerWorker.triggerNow(application)
            }
        }

        fun deleteProfile(profile: CurveProfile) {
            viewModelScope.launch {
                curveRepository.deleteProfile(profile)
                // Clear assignment if this profile was assigned
                if (appSettings.getEveningProfileIdSnapshot() == profile.id) {
                    appSettings.setEveningProfileId(-1L)
                }
                if (appSettings.getNightProfileIdSnapshot() == profile.id) {
                    appSettings.setNightProfileId(-1L)
                }
                SchedulerWorker.triggerNow(application)
            }
        }
    }
