package com.circadiandisplay.app.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.circadiandisplay.core.curve.DisplayMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "app_settings")

/**
 * Flat key-value settings backed by Jetpack DataStore (Preferences).
 *
 * Dual-curve Night Shift:
 * - Evening profile + Night profile (IDs in DataStore)
 * - Sun events (auto location or manual sunset/sunrise)
 * - Hardware white calibration offset
 * - Manual enable "until tomorrow"
 */
@Singleton
class AppSettings
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
    ) {
        private object Keys {
            val MODE = stringPreferencesKey("mode")
            val IS_ENABLED = booleanPreferencesKey("is_enabled")
            val LAST_EVALUATED_AT = longPreferencesKey("last_evaluated_at")
            // Legacy schedule / global temp (kept for migration / UI fallback)
            val SCHEDULE_START_MINUTES = intPreferencesKey("schedule_start_minutes")
            val SCHEDULE_END_MINUTES = intPreferencesKey("schedule_end_minutes")
            val COLOR_TEMPERATURE = floatPreferencesKey("color_temperature")
            val CALIBRATION_OFFSET_B = intPreferencesKey("calibration_offset_b")
            // Dual-curve keys
            val EVENING_PROFILE_ID = longPreferencesKey("evening_profile_id")
            val NIGHT_PROFILE_ID = longPreferencesKey("night_profile_id")
            val USE_SUN_EVENTS = booleanPreferencesKey("use_sun_events")
            val MANUAL_SUNSET_MINUTES = intPreferencesKey("manual_sunset_minutes")
            val MANUAL_SUNRISE_MINUTES = intPreferencesKey("manual_sunrise_minutes")
        }

        // ── Display Mode (kept for CompositeDisplayController auto-routing) ──

        val displayMode: Flow<DisplayMode> =
            context.dataStore.data.map { prefs ->
                val name = prefs[Keys.MODE] ?: DisplayMode.NATIVE.name
                runCatching { DisplayMode.valueOf(name) }.getOrDefault(DisplayMode.NATIVE)
            }

        suspend fun getDisplayModeSnapshot(): DisplayMode {
            val prefs = context.dataStore.data.first()
            val name = prefs[Keys.MODE] ?: DisplayMode.NATIVE.name
            return runCatching { DisplayMode.valueOf(name) }.getOrDefault(DisplayMode.NATIVE)
        }

        suspend fun setDisplayMode(mode: DisplayMode) {
            context.dataStore.edit { it[Keys.MODE] = mode.name }
        }

        // ── Master Toggle ("Włącz ręcznie do jutra") ─────────────────────────

        val isEnabled: Flow<Boolean> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.IS_ENABLED] ?: false
            }

        suspend fun isEnabledSnapshot(): Boolean {
            val prefs = context.dataStore.data.first()
            return prefs[Keys.IS_ENABLED] ?: false
        }

        suspend fun setEnabled(enabled: Boolean) {
            context.dataStore.edit { it[Keys.IS_ENABLED] = enabled }
        }

        // ── Dual-curve profile IDs ───────────────────────────────────────────

        val eveningProfileId: Flow<Long> =
            context.dataStore.data.map { it[Keys.EVENING_PROFILE_ID] ?: -1L }

        val nightProfileId: Flow<Long> =
            context.dataStore.data.map { it[Keys.NIGHT_PROFILE_ID] ?: -1L }

        suspend fun getEveningProfileIdSnapshot(): Long =
            context.dataStore.data.first()[Keys.EVENING_PROFILE_ID] ?: -1L

        suspend fun getNightProfileIdSnapshot(): Long =
            context.dataStore.data.first()[Keys.NIGHT_PROFILE_ID] ?: -1L

        suspend fun setEveningProfileId(id: Long) {
            context.dataStore.edit { it[Keys.EVENING_PROFILE_ID] = id }
        }

        suspend fun setNightProfileId(id: Long) {
            context.dataStore.edit { it[Keys.NIGHT_PROFILE_ID] = id }
        }

        // ── Sun events ──────────────────────────────────────────────────────

        val useSunEvents: Flow<Boolean> =
            context.dataStore.data.map { it[Keys.USE_SUN_EVENTS] ?: true }

        val manualSunsetMinutes: Flow<Int> =
            context.dataStore.data.map { it[Keys.MANUAL_SUNSET_MINUTES] ?: 1140 } // 19:00

        val manualSunriseMinutes: Flow<Int> =
            context.dataStore.data.map { it[Keys.MANUAL_SUNRISE_MINUTES] ?: 420 } // 07:00

        suspend fun setUseSunEvents(v: Boolean) {
            context.dataStore.edit { it[Keys.USE_SUN_EVENTS] = v }
        }

        suspend fun setManualSunsetMinutes(m: Int) {
            context.dataStore.edit {
                it[Keys.MANUAL_SUNSET_MINUTES] = m.coerceIn(0, 1439)
            }
        }

        suspend fun setManualSunriseMinutes(m: Int) {
            context.dataStore.edit {
                it[Keys.MANUAL_SUNRISE_MINUTES] = m.coerceIn(0, 1439)
            }
        }

        // ── Legacy schedule (kept for backward compatibility) ───────────────

        /** Default 22:00 */
        val scheduleStartMinutes: Flow<Int> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.SCHEDULE_START_MINUTES] ?: 22 * 60
            }

        suspend fun getScheduleStartSnapshot(): Int {
            val prefs = context.dataStore.data.first()
            return prefs[Keys.SCHEDULE_START_MINUTES] ?: 22 * 60
        }

        suspend fun setScheduleStartMinutes(minutes: Int) {
            context.dataStore.edit {
                it[Keys.SCHEDULE_START_MINUTES] = minutes.coerceIn(0, 1439)
            }
        }

        /** Default 07:00 */
        val scheduleEndMinutes: Flow<Int> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.SCHEDULE_END_MINUTES] ?: 7 * 60
            }

        suspend fun getScheduleEndSnapshot(): Int {
            val prefs = context.dataStore.data.first()
            return prefs[Keys.SCHEDULE_END_MINUTES] ?: 7 * 60
        }

        suspend fun setScheduleEndMinutes(minutes: Int) {
            context.dataStore.edit {
                it[Keys.SCHEDULE_END_MINUTES] = minutes.coerceIn(0, 1439)
            }
        }

        // ── Color temperature / warmth intensity (0.0 = less warm, 1.0 = more) ─

        val colorTemperature: Flow<Float> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.COLOR_TEMPERATURE] ?: 0.6f
            }

        suspend fun getColorTemperatureSnapshot(): Float {
            val prefs = context.dataStore.data.first()
            return prefs[Keys.COLOR_TEMPERATURE] ?: 0.6f
        }

        suspend fun setColorTemperature(value: Float) {
            context.dataStore.edit {
                it[Keys.COLOR_TEMPERATURE] = value.coerceIn(0f, 1f)
            }
        }

        // ── Hardware calibration: reduce native blue (0–255) ──────────────────

        val calibrationOffsetB: Flow<Int> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.CALIBRATION_OFFSET_B] ?: 0
            }

        suspend fun getCalibrationOffsetBSnapshot(): Int {
            val prefs = context.dataStore.data.first()
            return prefs[Keys.CALIBRATION_OFFSET_B] ?: 0
        }

        suspend fun setCalibrationOffsetB(value: Int) {
            context.dataStore.edit {
                it[Keys.CALIBRATION_OFFSET_B] = value.coerceIn(0, 255)
            }
        }

        // ── Diagnostics ───────────────────────────────────────────────────────

        val lastEvaluatedAt: Flow<Long> =
            context.dataStore.data.map { prefs ->
                prefs[Keys.LAST_EVALUATED_AT] ?: 0L
            }

        suspend fun setLastEvaluatedAt(timestampMs: Long) {
            context.dataStore.edit { it[Keys.LAST_EVALUATED_AT] = timestampMs }
        }

        /**
         * Whether Night Shift should be active right now (manual toggle).
         * Schedule window is now driven by sun events + curves in SchedulerWorker.
         */
        suspend fun isNightShiftActiveNow(nowMinutes: Int = currentTimeMinutes()): Boolean {
            if (isEnabledSnapshot()) return true
            val start = getScheduleStartSnapshot()
            val end = getScheduleEndSnapshot()
            return isTimeInSchedule(nowMinutes, start, end)
        }

        companion object {
            fun currentTimeMinutes(): Int {
                val cal = java.util.Calendar.getInstance()
                return cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 +
                    cal.get(java.util.Calendar.MINUTE)
            }

            fun isTimeInSchedule(now: Int, start: Int, end: Int): Boolean {
                return if (start <= end) {
                    // Same-day window, e.g. 09:00–17:00
                    now in start until end
                } else {
                    // Crosses midnight, e.g. 22:00–07:00
                    now >= start || now < end
                }
            }
        }
    }
