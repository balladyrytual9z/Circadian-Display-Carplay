
package com.circadiandisplay.app.ui.nightshift

import android.app.Application
import android.content.Intent
import android.provider.Settings
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.data.sun.SunEventProvider
import com.circadiandisplay.app.dock.DockNightModeReceiver
import com.circadiandisplay.app.scheduler.SchedulerWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NightShiftViewModel
    @Inject
    constructor(
        private val application: Application,
        private val appSettings: AppSettings,
        private val sunEvents: SunEventProvider,
    ) : ViewModel() {
        val uiState: StateFlow<NightShiftUiState> =
            combine(
                appSettings.isEnabled,
                appSettings.scheduleStartMinutes,
                appSettings.scheduleEndMinutes,
                appSettings.colorTemperature,
            ) { enabled, start, end, temp ->
                val now = AppSettings.currentTimeMinutes()
                val active =
                    enabled || AppSettings.isTimeInSchedule(now, start, end)
                NightShiftUiState(
                    isEnabled = enabled,
                    scheduleStartMinutes = start,
                    scheduleEndMinutes = end,
                    colorTemperature = temp,
                    isActiveNow = active,
                    overlayPermissionGranted = Settings.canDrawOverlays(application),
                )
            }.stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000),
                initialValue = NightShiftUiState(),
            )

        /**
         * Toggle "Włącz ręcznie do jutra" and notify Dock via broadcast (IPC feedback).
         */
        fun setEnabled(enabled: Boolean) {
            viewModelScope.launch {
                appSettings.setEnabled(enabled)
                sendNightModeBroadcast(enabled)
                SchedulerWorker.triggerNow(application)
            }
        }

        fun setScheduleStartMinutes(minutes: Int) {
            viewModelScope.launch {
                appSettings.setScheduleStartMinutes(minutes)
                SchedulerWorker.triggerNow(application)
            }
        }

        fun setScheduleEndMinutes(minutes: Int) {
            viewModelScope.launch {
                appSettings.setScheduleEndMinutes(minutes)
                SchedulerWorker.triggerNow(application)
            }
        }

        fun setColorTemperature(value: Float) {
            viewModelScope.launch {
                appSettings.setColorTemperature(value)
                SchedulerWorker.triggerNow(application)
            }
        }

        /**
         * Bidirectional IPC: inform Dock 2.0 about night-mode state changes.
         * Action matches [DockNightModeReceiver.ACTION_NIGHT_MODE_CHANGED].
         */
        private fun sendNightModeBroadcast(isNight: Boolean) {
            viewModelScope.launch {
                try {
                    val (sunset, sunrise) = sunEvents.today()
                    fun build(explicitPackage: String?): Intent =
                        Intent(DockNightModeReceiver.ACTION_NIGHT_MODE_CHANGED).apply {
                            putExtra(DockNightModeReceiver.EXTRA_IS_NIGHT, isNight)
                            putExtra("sunset_minutes", sunset)
                            putExtra("sunrise_minutes", sunrise)
                            if (explicitPackage != null) setPackage(explicitPackage)
                        }
                    application.sendBroadcast(build("pl.dock.launcher"))
                    application.sendBroadcast(build(null))
                    Log.i(TAG, "Broadcast NIGHT_MODE_CHANGED isNight=$isNight sunset=$sunset sunrise=$sunrise")
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to send night-mode broadcast: ${e.message}")
                }
            }
        }

        companion object {
            private const val TAG = "NightShiftVM"
        }
    }

