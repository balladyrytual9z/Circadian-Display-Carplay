
package com.circadiandisplay.app.ui.nightshift

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NightShiftScreen(
    viewModel: NightShiftViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToCurves: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Night Shift") },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = "Ustawienia",
                        )
                    }
                },
                colors =
                    TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                    ),
            )
        },
        modifier = modifier,
    ) { padding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Spacer(Modifier.height(4.dp))

            // Status
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (state.isActiveNow) "Aktywny" else "Nieaktywny",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color =
                            if (state.isActiveNow) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                    )
                    Text(
                        text =
                            if (state.isEnabled) {
                                "Włączony ręcznie do jutra"
                            } else {
                                "Według harmonogramu"
                            },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Manual toggle
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Włącz ręcznie do jutra",
                            style = MaterialTheme.typography.titleMedium,
                        )
                        Text(
                            text = "Wymusza Night Shift niezależnie od harmonogramu",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = state.isEnabled,
                        onCheckedChange = { viewModel.setEnabled(it) },
                    )
                }
            }

            // Schedule
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Harmonogram",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(12.dp))
                    TimeRow(
                        label = "Od",
                        minutes = state.scheduleStartMinutes,
                        onChange = { viewModel.setScheduleStartMinutes(it) },
                    )
                    Spacer(Modifier.height(8.dp))
                    TimeRow(
                        label = "Do",
                        minutes = state.scheduleEndMinutes,
                        onChange = { viewModel.setScheduleEndMinutes(it) },
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = formatScheduleHint(state.scheduleStartMinutes, state.scheduleEndMinutes),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Color temperature slider
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Temperatura barwowa",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = "Mniej ciepłe",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            text = "Bardziej ciepłe",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Slider(
                        value = state.colorTemperature,
                        onValueChange = { viewModel.setColorTemperature(it) },
                        valueRange = 0f..1f,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }


            // Curves shortcut
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToCurves() },
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column {
                        Text(
                            text = "Edytuj krzywe",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Text(
                            text = "Wieczór i Noc — punkty na osi czasu",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Text("→", style = MaterialTheme.typography.titleLarge)
                }
            }

            if (!state.overlayPermissionGranted) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Wymagane uprawnienie",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.error,
                        )
                        Text(
                            text =
                                "Aby nałożyć filtr kolorów, aplikacja potrzebuje " +
                                    "uprawnienia „Wyświetlanie nad innymi aplikacjami”. " +
                                    "Nadaj je w Ustawieniach systemowych.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TimeRow(
    label: String,
    minutes: Int,
    onChange: (Int) -> Unit,
) {
    val hours = minutes / 60
    val mins = minutes % 60
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(0.2f),
        )
        Text(
            text = "%02d:%02d".format(hours, mins),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.3f),
        )
        // Simple hour/minute steppers via slider of total minutes
        Slider(
            value = minutes.toFloat(),
            onValueChange = { onChange(it.toInt().coerceIn(0, 1439)) },
            valueRange = 0f..1439f,
            steps = 95, // ~15 min steps
            modifier = Modifier.weight(0.5f),
        )
    }
}

private fun formatScheduleHint(start: Int, end: Int): String {
    val s = "%02d:%02d".format(start / 60, start % 60)
    val e = "%02d:%02d".format(end / 60, end % 60)
    return if (start > end) {
        "Aktywny od $s do $e (przez północ)"
    } else {
        "Aktywny od $s do $e"
    }
}

