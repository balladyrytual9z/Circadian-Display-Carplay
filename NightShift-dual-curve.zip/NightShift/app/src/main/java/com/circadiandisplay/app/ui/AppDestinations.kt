package com.circadiandisplay.app.ui

/**
 * Navigation destinations for Night Shift with dual-curve support.
 */
object AppDestinations {
    const val NIGHT_SHIFT = "night_shift"
    const val SETTINGS = "settings"
    const val CALIBRATION = "calibration"
    const val EXCLUSIONS = "exclusions"
    const val CURVES = "curves"
    const val CURVE_EDITOR = "curve_editor/{profileId}"

    fun curveEditor(id: Long) = "curve_editor/$id"
}
