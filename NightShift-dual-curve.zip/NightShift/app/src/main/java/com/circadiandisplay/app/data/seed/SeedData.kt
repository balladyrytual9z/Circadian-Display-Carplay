package com.circadiandisplay.app.data.seed

import com.circadiandisplay.app.data.dao.CurvePointDao
import com.circadiandisplay.app.data.dao.CurveProfileDao
import com.circadiandisplay.app.data.entity.CurvePointEntity
import com.circadiandisplay.app.data.entity.CurveProfileEntity
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.data.sun.SunEventProvider
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Inserts default dual-curve data on first launch when the database is empty.
 *
 * Creates two profiles:
 * - "Wieczór" (Evening): sunset → 23:59
 * - "Noc" (Night): 00:00 → sunrise
 *
 * CurveEngine does not interpolate across midnight (Decision 007), so each
 * profile is linear within its own range.
 */
@Singleton
class SeedData
    @Inject
    constructor(
        private val profileDao: CurveProfileDao,
        private val pointDao: CurvePointDao,
        private val appSettings: AppSettings,
        private val sunEvents: SunEventProvider,
    ) {
        suspend fun seedIfNeeded() {
            if (profileDao.count() > 0) return

            val (sunset, sunrise) = sunEvents.today()

            // Profil "Wieczór": od zachodu do północy
            val eveningId =
                profileDao.insert(
                    CurveProfileEntity(
                        name = "Wieczór",
                        isActive = false,
                        createdAt = System.currentTimeMillis(),
                    ),
                )
            pointDao.insertAll(
                listOf(
                    CurvePointEntity(
                        profileId = eveningId,
                        timeMinutes = sunset,
                        warmth = 0.0f,
                        dimming = 0.0f,
                    ),
                    CurvePointEntity(
                        profileId = eveningId,
                        timeMinutes = ((sunset + 1440) / 2) % 1440,
                        warmth = 0.5f,
                        dimming = 0.15f,
                    ),
                    CurvePointEntity(
                        profileId = eveningId,
                        timeMinutes = 1439,
                        warmth = 0.9f,
                        dimming = 0.35f,
                    ),
                ),
            )

            // Profil "Noc": od północy do wschodu
            val nightId =
                profileDao.insert(
                    CurveProfileEntity(
                        name = "Noc",
                        isActive = false,
                        createdAt = System.currentTimeMillis(),
                    ),
                )
            pointDao.insertAll(
                listOf(
                    CurvePointEntity(
                        profileId = nightId,
                        timeMinutes = 0,
                        warmth = 0.9f,
                        dimming = 0.35f,
                    ),
                    CurvePointEntity(
                        profileId = nightId,
                        timeMinutes = (sunrise / 2).coerceAtLeast(1),
                        warmth = 1.0f,
                        dimming = 0.5f,
                    ),
                    CurvePointEntity(
                        profileId = nightId,
                        timeMinutes = sunrise,
                        warmth = 0.0f,
                        dimming = 0.0f,
                    ),
                ),
            )

            appSettings.setEveningProfileId(eveningId)
            appSettings.setNightProfileId(nightId)
        }
    }
