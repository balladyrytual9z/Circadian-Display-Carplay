
package com.circadiandisplay.app.ui.calibration

data class CalibrationUiState(
    /** 0 = no correction, 255 = maximum blue reduction. */
    val calibrationOffsetB: Int = 0,
)

