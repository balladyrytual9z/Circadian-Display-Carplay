
package com.circadiandisplay.app.di

import android.util.Log
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.core.curve.DisplayController
import com.circadiandisplay.core.curve.DisplayMode
import com.circadiandisplay.core.curve.DisplayState
import com.circadiandisplay.system.nativemode.NativeDisplayController
import com.circadiandisplay.system.overlay.OverlayDisplayController
import kotlinx.coroutines.runBlocking
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Runtime-delegating [DisplayController].
 *
 * Night Shift simplification (Prompt 1 §5):
 * - Prefer [DisplayMode.NATIVE] automatically when the device supports it
 *   (API 29+ and WRITE_SECURE_SETTINGS granted).
 * - On any failure or unsupported device, fall back silently to OVERLAY.
 * - Display Mode UI is hidden; this class owns the routing policy.
 *
 * Also pushes [AppSettings] calibration offset into the overlay controller
 * so the always-on white-calibration layer stays in sync.
 */
@Singleton
class CompositeDisplayController
    @Inject
    constructor(
        private val overlay: OverlayDisplayController,
        private val native: NativeDisplayController,
        private val appSettings: AppSettings,
    ) : DisplayController {
        private fun preferNative(): Boolean = native.isSupported()

        private fun syncCalibration() {
            val offset =
                try {
                    runBlocking { appSettings.getCalibrationOffsetBSnapshot() }
                } catch (_: Exception) {
                    0
                }
            overlay.calibrationOffsetB = offset
        }

        override fun apply(state: DisplayState) {
            syncCalibration()

            // Auto-prefer NATIVE; silent fallback to OVERLAY
            if (preferNative()) {
                try {
                    overlay.clear()
                    // Keep overlay for calibration layer if needed
                    if (overlay.calibrationOffsetB > 0) {
                        // Native does not apply calibration; keep overlay for layer 1 only
                        overlay.apply(DisplayState(warmth = 0f, dimming = 0f))
                    }
                    Log.d(TAG, "Dispatching apply() → NativeDisplayController")
                    native.apply(state)
                    // Persist preferred mode for diagnostics
                    runBlocking { appSettings.setDisplayMode(DisplayMode.NATIVE) }
                    return
                } catch (e: Exception) {
                    Log.w(TAG, "Native apply failed, falling back to Overlay: ${e.message}")
                }
            }

            native.clear()
            Log.d(TAG, "Dispatching apply() → OverlayDisplayController")
            overlay.apply(state)
            runBlocking { appSettings.setDisplayMode(DisplayMode.OVERLAY) }
        }

        override fun clear() {
            Log.d(TAG, "Clearing both Overlay and Native controllers")
            native.clear()
            // clear() on overlay preserves calibration-only layer when offset > 0
            overlay.clear()
        }

        override fun isSupported(): Boolean {
            // Supported if either path works
            return overlay.isSupported() || native.isSupported()
        }

        companion object {
            private const val TAG = "CompositeDisplayCtrl"
        }
    }

