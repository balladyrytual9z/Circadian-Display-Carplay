package com.circadiandisplay.app.ui.profiles

import com.circadiandisplay.core.curve.CurveProfile

/**
 * Immutable UI state for the Profiles / Curves screen.
 *
 * @property isLoading True until the first database emission arrives.
 * @property profiles  All profiles, most recently created first.
 * @property eveningProfileId Currently assigned evening curve ID (-1 if none).
 * @property nightProfileId Currently assigned night curve ID (-1 if none).
 */
data class ProfilesUiState(
    val isLoading: Boolean = true,
    val profiles: List<CurveProfile> = emptyList(),
    val eveningProfileId: Long = -1L,
    val nightProfileId: Long = -1L,
)
