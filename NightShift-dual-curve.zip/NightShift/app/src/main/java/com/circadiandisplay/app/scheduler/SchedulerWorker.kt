package com.circadiandisplay.app.scheduler

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.circadiandisplay.app.data.repository.CurveRepository
import com.circadiandisplay.app.data.repository.ExclusionRepository
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.data.sun.SunEventProvider
import com.circadiandisplay.app.foreground.ForegroundAppProvider
import com.circadiandisplay.core.curve.CurveEngine
import com.circadiandisplay.core.curve.DisplayController
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Periodic background worker for dual-curve Night Shift.
 *
 * Selects evening profile (sunset..23:59) or night profile (00:00..sunrise)
 * based on current local time and sun events, then evaluates CurveEngine.
 */
@HiltWorker
@Suppress("LongParameterList")
class SchedulerWorker
    @AssistedInject
    constructor(
        @Assisted appContext: Context,
        @Assisted workerParams: WorkerParameters,
        private val appSettings: AppSettings,
        private val displayController: DisplayController,
        private val exclusionRepository: ExclusionRepository,
        private val foregroundAppProvider: ForegroundAppProvider,
        private val curveRepository: CurveRepository,
        private val curveEngine: CurveEngine,
        private val sunEvents: SunEventProvider,
    ) : CoroutineWorker(appContext, workerParams) {
        @Suppress("TooGenericExceptionCaught")
        override suspend fun doWork(): Result {
            return try {
                evaluateAndApply()
                Result.success()
            } catch (e: Exception) {
                Log.e(TAG, "Scheduler evaluation failed", e)
                Result.retry()
            }
        }

        private suspend fun evaluateAndApply() {
            val enabled = appSettings.isEnabledSnapshot()
            if (!enabled) {
                // Still respect schedule via sun events when manual toggle is off
                // (enabled=false means user turned off; we still evaluate curves
                // only when inside the sun window — see isNight below).
            }

            val fg = foregroundAppProvider.currentForegroundPackage()
            if (fg != null && exclusionRepository.isExcluded(fg)) {
                Log.d(TAG, "Excluded app in foreground ($fg) — clearing display")
                displayController.clear()
                appSettings.setLastEvaluatedAt(System.currentTimeMillis())
                return
            }

            val now = AppSettings.currentTimeMinutes()
            val (sunset, sunrise) = sunEvents.today()
            // Active when manual toggle OR inside night window (after sunset or before sunrise)
            val isNightWindow = now < sunrise || now >= sunset
            val active = enabled || isNightWindow

            if (!active) {
                Log.d(TAG, "Outside night window and not manually enabled — clearing")
                displayController.clear()
                appSettings.setLastEvaluatedAt(System.currentTimeMillis())
                return
            }

            // Choose profile: evening (sunset..1439) or night (0..sunrise)
            val profileId =
                if (now >= sunset) {
                    appSettings.getEveningProfileIdSnapshot()
                } else {
                    appSettings.getNightProfileIdSnapshot()
                }

            if (profileId <= 0) {
                Log.w(TAG, "No profile assigned for current period — clearing")
                displayController.clear()
                appSettings.setLastEvaluatedAt(System.currentTimeMillis())
                return
            }

            val profile = curveRepository.getProfileById(profileId)
            if (profile == null) {
                Log.w(TAG, "Profile $profileId not found — clearing")
                displayController.clear()
                appSettings.setLastEvaluatedAt(System.currentTimeMillis())
                return
            }

            val points = curveRepository.getPointsByProfileIdOnce(profileId)
            val state = curveEngine.calculateDisplayState(profile, points, now)
            Log.d(
                TAG,
                "Applying curve '${profile.name}' at $now " +
                    "(${"%02d:%02d".format(now / 60, now % 60)}): " +
                    "warmth=${"%.2f".format(state.warmth)}, dimming=${"%.2f".format(state.dimming)}",
            )
            displayController.apply(state)
            appSettings.setLastEvaluatedAt(System.currentTimeMillis())
        }

        companion object {
            private const val TAG = "SchedulerWorker"
            private const val UNIQUE_PERIODIC_NAME = "circadian_scheduler_periodic"
            private const val UNIQUE_ONESHOT_NAME = "circadian_scheduler_oneshot"
            private const val PERIOD_MINUTES = 15L

            fun enqueuePeriodic(context: Context) {
                val request =
                    PeriodicWorkRequestBuilder<SchedulerWorker>(
                        PERIOD_MINUTES,
                        TimeUnit.MINUTES,
                    ).build()
                WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                    UNIQUE_PERIODIC_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request,
                )
            }

            fun triggerNow(context: Context) {
                val request = OneTimeWorkRequestBuilder<SchedulerWorker>().build()
                WorkManager.getInstance(context).enqueueUniqueWork(
                    UNIQUE_ONESHOT_NAME,
                    ExistingWorkPolicy.REPLACE,
                    request,
                )
            }
        }
    }
