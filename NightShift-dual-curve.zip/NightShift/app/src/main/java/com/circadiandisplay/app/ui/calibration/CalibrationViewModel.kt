
package com.circadiandisplay.app.ui.calibration

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.scheduler.SchedulerWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CalibrationViewModel
    @Inject
    constructor(
        private val application: Application,
        private val appSettings: AppSettings,
    ) : ViewModel() {
        val uiState: StateFlow<CalibrationUiState> =
            appSettings.calibrationOffsetB
                .map { CalibrationUiState(calibrationOffsetB = it) }
                .stateIn(
                    scope = viewModelScope,
                    started = SharingStarted.WhileSubscribed(5_000),
                    initialValue = CalibrationUiState(),
                )

        fun setCalibrationOffsetB(value: Int) {
            viewModelScope.launch {
                appSettings.setCalibrationOffsetB(value)
                // Re-apply overlay so calibration layer updates immediately
                SchedulerWorker.triggerNow(application)
            }
        }
    }

