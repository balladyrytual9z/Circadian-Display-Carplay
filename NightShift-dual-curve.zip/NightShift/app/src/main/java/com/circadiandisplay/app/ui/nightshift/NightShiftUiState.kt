
package com.circadiandisplay.app.ui.nightshift

/**
 * UI state for the main Night Shift screen.
 */
data class NightShiftUiState(
    /** Manual "Włącz ręcznie do jutra". */
    val isEnabled: Boolean = false,
    /** Schedule start, minutes since midnight. */
    val scheduleStartMinutes: Int = 22 * 60,
    /** Schedule end, minutes since midnight. */
    val scheduleEndMinutes: Int = 7 * 60,
    /** Global color temperature / warmth intensity 0..1. */
    val colorTemperature: Float = 0.6f,
    /** Whether Night Shift is effectively active right now. */
    val isActiveNow: Boolean = false,
    val overlayPermissionGranted: Boolean = false,
)

