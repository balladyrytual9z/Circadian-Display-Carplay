package com.circadiandisplay.app.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.circadiandisplay.app.ui.calibration.CalibrationScreen
import com.circadiandisplay.app.ui.calibration.CalibrationViewModel
import com.circadiandisplay.app.ui.editor.CurveEditorScreen
import com.circadiandisplay.app.ui.editor.CurveEditorViewModel
import com.circadiandisplay.app.ui.exclusions.ExclusionsScreen
import com.circadiandisplay.app.ui.exclusions.ExclusionsViewModel
import com.circadiandisplay.app.ui.nightshift.NightShiftScreen
import com.circadiandisplay.app.ui.nightshift.NightShiftViewModel
import com.circadiandisplay.app.ui.profiles.ProfilesScreen
import com.circadiandisplay.app.ui.profiles.ProfilesViewModel
import com.circadiandisplay.app.ui.settings.SettingsScreen
import com.circadiandisplay.app.ui.settings.SettingsViewModel

/**
 * Top-level navigation for dual-curve Night Shift.
 * Start destination is [AppDestinations.NIGHT_SHIFT].
 */
@Composable
fun AppNavHost() {
    val navController = rememberNavController()

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppDestinations.NIGHT_SHIFT,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(AppDestinations.NIGHT_SHIFT) {
                val viewModel: NightShiftViewModel = hiltViewModel()
                NightShiftScreen(
                    viewModel = viewModel,
                    onNavigateToSettings = {
                        navController.navigate(AppDestinations.SETTINGS)
                    },
                    onNavigateToCurves = {
                        navController.navigate(AppDestinations.CURVES)
                    },
                )
            }
            composable(AppDestinations.SETTINGS) {
                val viewModel: SettingsViewModel = hiltViewModel()
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToExclusions = {
                        navController.navigate(AppDestinations.EXCLUSIONS)
                    },
                    onNavigateToCalibration = {
                        navController.navigate(AppDestinations.CALIBRATION)
                    },
                )
            }
            composable(AppDestinations.CALIBRATION) {
                val viewModel: CalibrationViewModel = hiltViewModel()
                CalibrationScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                )
            }
            composable(AppDestinations.EXCLUSIONS) {
                val viewModel: ExclusionsViewModel = hiltViewModel()
                ExclusionsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                )
            }
            composable(AppDestinations.CURVES) {
                val viewModel: ProfilesViewModel = hiltViewModel()
                ProfilesScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onEditProfile = { id ->
                        navController.navigate(AppDestinations.curveEditor(id))
                    },
                )
            }
            composable(
                route = AppDestinations.CURVE_EDITOR,
                arguments = listOf(navArgument("profileId") { type = NavType.LongType }),
            ) {
                val viewModel: CurveEditorViewModel = hiltViewModel()
                CurveEditorScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                )
            }
        }
    }
}
