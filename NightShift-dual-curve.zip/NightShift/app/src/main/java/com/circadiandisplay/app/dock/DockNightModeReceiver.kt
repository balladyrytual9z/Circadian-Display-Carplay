

package com.circadiandisplay.app.dock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.scheduler.SchedulerWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

/**
 * Receives [ACTION_NIGHT_MODE_CHANGED] broadcasts from Dock
 * (`pl.dock.widget.NIGHT_MODE_CHANGED`) and mirrors day/night into
 * Circadian's master enable switch + immediate scheduler tick.
 *
 * Registered in the manifest with `exported="false"` and an explicit
 * intent-filter; Dock must target this package via `Intent.setPackage(...)`.
 *
 * Hardening (Android 9 / Dock 2.0):
 * - [goAsync] so work can finish after onReceive returns.
 * - Broad try/catch so a failed DataStore/WorkManager path never crashes
 *   the process when Dock is force-stopped or sends a malformed Intent.
 */
@AndroidEntryPoint
class DockNightModeReceiver : BroadcastReceiver() {

    @Inject
    lateinit var appSettings: AppSettings

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null || intent.action != ACTION_NIGHT_MODE_CHANGED) return

        val isNight =
            try {
                intent.getBooleanExtra(EXTRA_IS_NIGHT, false)
            } catch (e: Exception) {
                Log.w(TAG, "Malformed isNight extra: ${e.message}")
                false
            }

        Log.i(TAG, "NIGHT_MODE_CHANGED isNight=$isNight")

        val pending = goAsync()
        try {
            runBlocking {
                appSettings.setEnabled(isNight)
            }
            SchedulerWorker.triggerNow(context.applicationContext)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to apply night mode from Dock", t)
        } finally {
            try {
                pending.finish()
            } catch (e: Exception) {
                Log.w(TAG, "pendingResult.finish failed: ${e.message}")
            }
        }
    }

    companion object {
        private const val TAG = "DockNightModeRx"

        /** Must match CircadianBridge / Dock night-mode broadcast action. */
        const val ACTION_NIGHT_MODE_CHANGED = "pl.dock.widget.NIGHT_MODE_CHANGED"
        const val EXTRA_IS_NIGHT = "isNight"
    }
}


