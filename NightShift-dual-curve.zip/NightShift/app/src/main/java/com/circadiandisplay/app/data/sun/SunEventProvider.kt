package com.circadiandisplay.app.data.sun

import android.content.Context
import android.location.LocationManager
import com.circadiandisplay.app.data.settings.AppSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/**
 * Provides today's sunset and sunrise times as minutes since midnight.
 *
 * - If [AppSettings.useSunEvents] is false → returns manual values from settings.
 * - Otherwise tries last-known location (coarse) and computes via a simplified NOAA algorithm.
 * - Fallback when no location: 19:00 / 07:00.
 */
@Singleton
class SunEventProvider
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
        private val appSettings: AppSettings,
    ) {
        /**
         * Returns (sunsetMinutes, sunriseMinutes) in minutes from midnight.
         */
        suspend fun today(): Pair<Int, Int> {
            if (!appSettings.useSunEvents.first()) {
                return appSettings.manualSunsetMinutes.first() to appSettings.manualSunriseMinutes.first()
            }
            val loc = lastKnownLocation() ?: return 1140 to 420
            return compute(loc.latitude, loc.longitude)
        }

        private fun lastKnownLocation(): android.location.Location? {
            val lm =
                context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                    ?: return null
            return try {
                lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            } catch (_: SecurityException) {
                null
            }
        }

        /** Simplified NOAA sunrise/sunset algorithm — accuracy ≈ ±3 min. */
        private fun compute(
            lat: Double,
            lon: Double,
        ): Pair<Int, Int> {
            val cal = Calendar.getInstance()
            val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
            val zenith = 90.833
            val lngHour = lon / 15.0

            fun event(isSunrise: Boolean): Int {
                val t = dayOfYear + ((if (isSunrise) 6 else 18) - lngHour) / 24.0
                val m = 0.9856 * t - 3.289
                val l =
                    m + 1.916 * sin(Math.toRadians(m)) +
                        0.020 * sin(Math.toRadians(2 * m)) + 282.634
                val lNorm = ((l % 360) + 360) % 360
                var ra = Math.toDegrees(atan(0.91764 * tan(Math.toRadians(lNorm))))
                ra = ((ra % 360) + 360) % 360
                val lQuadrant = floor(lNorm / 90) * 90
                val raQuadrant = floor(ra / 90) * 90
                ra += (lQuadrant - raQuadrant)
                ra /= 15.0
                val sinDec = 0.39782 * sin(Math.toRadians(lNorm))
                val cosDec = cos(asin(sinDec))
                val cosH =
                    (cos(Math.toRadians(zenith)) - sinDec * sin(Math.toRadians(lat))) /
                        (cosDec * cos(Math.toRadians(lat)))
                if (cosH > 1 || cosH < -1) return if (isSunrise) 420 else 1140
                val h =
                    if (isSunrise) {
                        360 - Math.toDegrees(acos(cosH))
                    } else {
                        Math.toDegrees(acos(cosH))
                    }
                val tLocal = h / 15.0 + ra - 0.06571 * t - 6.622
                val ut = ((tLocal - lngHour) % 24 + 24) % 24
                val tzOffsetHours =
                    (cal.get(Calendar.ZONE_OFFSET) + cal.get(Calendar.DST_OFFSET)) / 3_600_000.0
                val localHours = (ut + tzOffsetHours) % 24
                return ((localHours * 60).toInt() + 1440) % 1440
            }

            // compute returns (sunset, sunrise) to match call-site convention in SeedData / Worker
            val sunrise = event(true)
            val sunset = event(false)
            return sunset to sunrise
        }
    }
