
package com.circadiandisplay.system.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.input.InputManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.circadiandisplay.core.curve.DisplayController
import com.circadiandisplay.core.curve.DisplayState
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Full-screen software overlay with two independent color layers:
 *
 * 1. **Calibration layer** (always active when calibration_offset_b > 0):
 *    Gentle warm filter to correct cold native white on cheap LCDs.
 *    Example: Color.argb(30, 255, 230, 255 - offsetB)
 *
 * 2. **Night Shift layer** (only when night mode is active):
 *    Amber tint (R:255, G:179, B:0) with intensity from the color-temperature slider.
 *    [DisplayState.warmth] drives this layer; dimming is optional residual support.
 *
 * Requires [android.permission.SYSTEM_ALERT_WINDOW].
 */
@Singleton
class OverlayDisplayController
    @Inject
    constructor(
        @ApplicationContext private val context: Context,
    ) : DisplayController {
        private val windowManager: WindowManager =
            context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        private val mainHandler = Handler(Looper.getMainLooper())

        private val windowAlpha: Float =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val max =
                    context.getSystemService(InputManager::class.java)
                        ?.maximumObscuringOpacityForTouch
                max?.coerceIn(0f, 1f) ?: DEFAULT_MAX_OBSCURING_OPACITY
            } else {
                1f
            }

        private var overlayView: OverlayView? = null

        /**
         * Hardware calibration offset (0–255). Set from AppSettings before/alongside apply.
         * Kept as a field so the always-on calibration layer can be updated independently
         * of Night Shift warmth.
         */
        @Volatile
        var calibrationOffsetB: Int = 0
            set(value) {
                field = value.coerceIn(0, 255)
                mainHandler.post {
                    overlayView?.let {
                        it.calibrationOffsetB = field
                        it.invalidate()
                        // Ensure view exists even when night is off so calibration shows
                        if (field > 0 && overlayView == null) {
                            // will be created on next apply/ensure
                        }
                    }
                    ensureCalibrationVisible()
                }
            }

        override fun apply(state: DisplayState) {
            if (!isSupported()) {
                Log.w(TAG, "SYSTEM_ALERT_WINDOW not granted — skipping overlay apply")
                return
            }
            mainHandler.post {
                applyOnMainThread(state)
            }
        }

        override fun clear() {
            mainHandler.post {
                // Keep calibration-only overlay if offset > 0; otherwise remove fully
                if (calibrationOffsetB > 0) {
                    applyOnMainThread(DisplayState(warmth = 0f, dimming = 0f))
                } else {
                    clearOnMainThread()
                }
            }
        }

        override fun isSupported(): Boolean = Settings.canDrawOverlays(context)

        private fun ensureCalibrationVisible() {
            if (!isSupported()) return
            if (calibrationOffsetB > 0 && overlayView == null) {
                applyOnMainThread(DisplayState(warmth = 0f, dimming = 0f))
            } else if (calibrationOffsetB == 0) {
                val view = overlayView
                if (view != null && view.warmthAlpha <= 0f && view.dimmingAlpha <= 0f) {
                    clearOnMainThread()
                }
            }
        }

        private fun applyOnMainThread(state: DisplayState) {
            val warmth = state.warmth.coerceIn(0f, 1f)
            val dimming = state.dimming.coerceIn(0f, 1f)
            val compensation = 1f / windowAlpha

            val view = getOrCreateOverlayView()
            view.calibrationOffsetB = calibrationOffsetB
            view.dimmingAlpha = (dimming * compensation).coerceIn(0f, 1f)
            view.warmthAlpha = (warmth * MAX_WARMTH_ALPHA * compensation).coerceIn(0f, 1f)
            view.invalidate()
        }

        private fun clearOnMainThread() {
            overlayView?.let { removeViewSafely(it) }
            overlayView = null
        }

        private fun getOrCreateOverlayView(): OverlayView =
            overlayView ?: createOverlayView().also { overlayView = it }

        private fun createOverlayView(): OverlayView {
            val view = OverlayView(context)

            val layoutType =
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

            val params =
                WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT,
                )

            params.gravity = Gravity.TOP or Gravity.START
            params.x = 0
            params.y = 0
            params.alpha = windowAlpha
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                params.layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
            }

            windowManager.addView(view, params)
            return view
        }

        private fun removeViewSafely(view: View) {
            try {
                windowManager.removeView(view)
            } catch (_: IllegalArgumentException) {
            }
        }

        companion object {
            private const val TAG = "OverlayDisplayCtrl"
            private const val MAX_WARMTH_ALPHA = 0.5f
            private const val AMBER_RED = 0xFF
            private const val AMBER_GREEN = 0xB3
            private const val AMBER_BLUE = 0x00
            private const val DEFAULT_MAX_OBSCURING_OPACITY = 0.8f
            /** Fixed alpha for the always-on calibration filter. */
            private const val CALIBRATION_ALPHA = 30
        }

        /**
         * Draws two layers:
         * 1. Calibration (always, if offsetB > 0) — soft warm white correction
         * 2. Night Shift amber (when warmthAlpha > 0)
         * Optional dimming (black) remains for residual support.
         */
        private class OverlayView(context: Context) : View(context) {
            var dimmingAlpha: Float = 0f
            var warmthAlpha: Float = 0f
            var calibrationOffsetB: Int = 0

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)

                // Layer 1 — calibration (always active when offset > 0)
                if (calibrationOffsetB > 0) {
                    val blue = (255 - calibrationOffsetB).coerceIn(0, 255)
                    canvas.drawColor(
                        Color.argb(CALIBRATION_ALPHA, 255, 230, blue),
                    )
                }

                // Optional dimming
                if (dimmingAlpha > 0f) {
                    canvas.drawColor(
                        Color.argb((dimmingAlpha * 255).toInt().coerceIn(0, 255), 0, 0, 0),
                    )
                }

                // Layer 2 — Night Shift amber
                if (warmthAlpha > 0f) {
                    canvas.drawColor(
                        Color.argb(
                            (warmthAlpha * 255).toInt().coerceIn(0, 255),
                            AMBER_RED,
                            AMBER_GREEN,
                            AMBER_BLUE,
                        ),
                    )
                }
            }
        }
    }

