
# Night Shift — instrukcja zastosowania patcha (Prompt 1)

Skopiuj pliki z katalogu `nightshift_patch/` na odpowiadające ścieżki w projekcie
`CircadianDisplay-dock-1.0.5/`.

## Pliki do podmiany / dodania

| Źródło w patchu | Cel w projekcie |
|-----------------|-----------------|
| `app/.../strings.xml` | `app/src/main/res/values/strings.xml` |
| `app/.../AppSettings.kt` | `app/src/main/java/.../data/settings/AppSettings.kt` |
| `app/.../AppDestinations.kt` | `app/src/main/java/.../ui/AppDestinations.kt` |
| `app/.../AppNavHost.kt` | `app/src/main/java/.../ui/AppNavHost.kt` |
| `app/.../nightshift/*` | **NOWY** pakiet `ui/nightshift/` |
| `app/.../calibration/*` | **NOWY** pakiet `ui/calibration/` |
| `app/.../settings/SettingsScreen.kt` | podmiana (ukryty Display Mode + link do kalibracji) |
| `app/.../di/CompositeDisplayController.kt` | auto NATIVE → fallback OVERLAY |
| `app/.../scheduler/SchedulerWorker.kt` | logika harmonogramu zamiast krzywych |
| `system/overlay/.../OverlayDisplayController.kt` | dwie warstwy (kalibracja + Night Shift) |

## Co zostało zrobione względem Prompt 1

1. **UI uproszczone**
   - Usunięty `NavigationBar` oraz trasy Dashboard / Profiles / CurveEditor / Preview.
   - Nowy główny ekran `NightShiftScreen`: przełącznik „Włącz ręcznie do jutra”,
     harmonogram Od–Do, suwak „Temperatura barwowa”.
   - `app_name` → **Night Shift** (package `com.circadiandisplay.app` bez zmian).

2. **CalibrationScreen**
   - Suwak „Redukcja natywnego niebieskiego” → `AppSettings.calibration_offset_b` (0–255).

3. **OverlayDisplayController**
   - Warstwa 1 (zawsze, gdy offset > 0): `Color.argb(30, 255, 230, 255 - offsetB)`.
   - Warstwa 2 (Night Shift): bursztyn `#FFB300` tylko przy aktywnym trybie nocnym;
     intensywność = suwak temperatury (`DisplayState.warmth`).

4. **IPC / broadcast do Dock 2.0**
   - W `NightShiftViewModel.setEnabled()` wysyłany jest
     `pl.dock.widget.NIGHT_MODE_CHANGED` z extra `isNight` (oraz `setPackage("pl.dock.launcher")`).

5. **Ukrycie Display Mode**
   - Brak radio buttons w Settings.
   - `CompositeDisplayController` preferuje NATIVE gdy `isSupported()`, przy błędzie
     cicho przechodzi na OVERLAY; kalibracja nadal przez overlay.

## Scheduler

`SchedulerWorker` nie czyta już krzywych Room. Aktywność =  
`isEnabled` **lub** czas w oknie harmonogramu (z obsługą północy).  
Warmth = globalny `colorTemperature`.

## Uwagi integracyjne

- Stare ekrany (Dashboard, Profiles, CurveEditor, Preview) mogą pozostać w drzewie
  źródeł, ale nie są już w grafie nawigacji — można je usunąć w kolejnym kroku.
- `DockStateProvider` / `DockNightModeReceiver` działają bez zmian (setEnabled + triggerNow).
- Po podmianie: `./gradlew :app:assembleDebug`.
- Ekran ustawień wymaga nowego parametru `onNavigateToCalibration` — już podpięty
  w zaktualizowanym `AppNavHost`.

