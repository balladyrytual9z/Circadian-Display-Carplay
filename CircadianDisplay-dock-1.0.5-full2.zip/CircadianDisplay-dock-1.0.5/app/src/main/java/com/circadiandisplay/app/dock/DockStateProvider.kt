package com.circadiandisplay.app.dock

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import android.os.Process
import android.util.Log
import com.circadiandisplay.app.data.repository.CurveRepository
import com.circadiandisplay.app.data.settings.AppSettings
import com.circadiandisplay.app.scheduler.SchedulerWorker
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.runBlocking

/**
 * ContentProvider exposed for Dock launcher integration (CarPlay / Dock 2.0).
 *
 * Authority: [AUTHORITY] (`com.circadiandisplay.app.state`)
 *
 * Methods expected by Dock's CircadianBridge:
 *
 * | method              | extras              | result                          |
 * |---------------------|---------------------|---------------------------------|
 * | activate_for_night  | –                   | Bundle(`ok` = Boolean)          |
 * | set_night_mode      | `isNight` (Boolean) | Bundle(`ok` = Boolean)          |
 * | get_status          | –                   | Bundle(`enabled`, `isNight`, …) |
 *
 * Security (Android 9 / IPC hardening):
 * - Control methods require a trusted caller package (Dock launcher / widget)
 *   or the same UID as this app. Untrusted callers get [SecurityException].
 * - Status reads are allowed more broadly so tools can probe installation
 *   without side effects.
 * - All mutating paths are wrapped in try/catch so a Dock-side failure or
 *   process death never crashes Circadian via the Binder call.
 */
class DockStateProvider : ContentProvider() {

    @EntryPoint
    @InstallIn(SingletonComponent::class)
    interface DockEntryPoint {
        fun curveRepository(): CurveRepository
        fun appSettings(): AppSettings
    }

    private fun entryPoint(): DockEntryPoint {
        val ctx = context ?: error("Context not available")
        return EntryPointAccessors.fromApplication(ctx.applicationContext, DockEntryPoint::class.java)
    }

    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val ctx = context ?: return fail("no context")
        return when (method) {
            METHOD_ACTIVATE_FOR_NIGHT -> {
                requireTrustedCaller(ctx)
                activateForNight()
            }
            METHOD_SET_NIGHT_MODE -> {
                requireTrustedCaller(ctx)
                val isNight =
                    try {
                        extras?.getBoolean(EXTRA_IS_NIGHT, false) ?: false
                    } catch (_: Exception) {
                        false
                    }
                setNightMode(isNight)
            }
            METHOD_GET_STATUS -> getStatus()
            else -> {
                Log.w(TAG, "Unknown method: $method")
                null
            }
        }
    }

    /**
     * Dock calls this when the car UI switches to night look and
     * circadian auto is enabled. Ensures Circadian is on and the
     * active curve is evaluated immediately.
     */
    private fun activateForNight(): Bundle {
        return try {
            val ep = entryPoint()
            runBlocking {
                ep.appSettings().setEnabled(true)
            }
            // Kick the scheduler so overlay/native applies without waiting
            // for the next 15-minute WorkManager tick.
            context?.let { SchedulerWorker.triggerNow(it) }
            Log.i(TAG, "activate_for_night → ok")
            ok()
        } catch (t: Throwable) {
            Log.e(TAG, "activate_for_night failed", t)
            fail(t.message ?: "error")
        }
    }

    /**
     * Explicit day/night toggle from Dock.
     * - night → enable Circadian + immediate evaluate
     * - day   → disable Circadian (clear filters via scheduler)
     */
    private fun setNightMode(isNight: Boolean): Bundle {
        return try {
            val ep = entryPoint()
            runBlocking {
                ep.appSettings().setEnabled(isNight)
            }
            context?.let { SchedulerWorker.triggerNow(it) }
            Log.i(TAG, "set_night_mode isNight=$isNight → ok")
            ok()
        } catch (t: Throwable) {
            Log.e(TAG, "set_night_mode failed", t)
            fail(t.message ?: "error")
        }
    }

    private fun getStatus(): Bundle {
        return try {
            val ep = entryPoint()
            val enabled = runBlocking { ep.appSettings().isEnabledSnapshot() }
            val mode = runBlocking { ep.appSettings().getDisplayModeSnapshot() }
            Bundle().apply {
                putBoolean("ok", true)
                putBoolean("enabled", enabled)
                putBoolean("isNight", enabled)
                putString("mode", mode.name)
                putString("package", context?.packageName)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "get_status failed", t)
            fail(t.message ?: "error")
        }
    }

    /**
     * Verifies the Binder caller is trusted. Prefer [getCallingPackage] (stable
     * on Android 9 / API 28); fall back to UID → package list.
     *
     * Trusted:
     * - same UID as this process
     * - [TRUSTED_DOCK_PACKAGES] (`pl.dock.widget`, `pl.dock.launcher`)
     * - this app's own package name
     *
     * @throws SecurityException if the caller is not trusted
     */
    private fun requireTrustedCaller(ctx: android.content.Context) {
        if (isTrustedCaller(ctx)) return
        Log.w(TAG, "Odrzucono niezaufane wywołanie IPC (caller not trusted)")
        throw SecurityException("Caller not trusted")
    }

    private fun isTrustedCaller(ctx: android.content.Context): Boolean {
        val uid = Binder.getCallingUid()
        if (uid == Process.myUid()) return true

        // Primary path on API 28+: package name of the Binder peer.
        val callingPackage =
            try {
                callingPackage
            } catch (_: Exception) {
                null
            }
        if (callingPackage != null) {
            if (callingPackage in TRUSTED_DOCK_PACKAGES) return true
            if (callingPackage == ctx.packageName) return true
        }

        // Fallback: resolve packages for the calling UID.
        val pkgs =
            try {
                ctx.packageManager.getPackagesForUid(uid)
            } catch (_: Exception) {
                null
            } ?: return false

        return pkgs.any { it in TRUSTED_DOCK_PACKAGES || it == ctx.packageName }
    }

    private fun ok(): Bundle = Bundle().apply { putBoolean("ok", true) }

    private fun fail(reason: String): Bundle =
        Bundle().apply {
            putBoolean("ok", false)
            putString("error", reason)
        }

    // Unused CRUD – this provider is call()-only
    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?,
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?,
    ): Int = 0

    companion object {
        private const val TAG = "DockStateProvider"

        const val AUTHORITY = "com.circadiandisplay.app.state"

        /**
         * Dock 2.0 / CarPlay launcher packages allowed to call control methods.
         * `pl.dock.widget` — classic widget / bridge package.
         * `pl.dock.launcher` — Dock 2.0 launcher process (Android 9 units).
         */
        val TRUSTED_DOCK_PACKAGES: Set<String> =
            setOf(
                "pl.dock.widget",
                "pl.dock.launcher",
            )

        /** @deprecated Use [TRUSTED_DOCK_PACKAGES]; kept for binary compatibility with docs. */
        const val TRUSTED_DOCK_PACKAGE = "pl.dock.widget"

        const val METHOD_ACTIVATE_FOR_NIGHT = "activate_for_night"
        const val METHOD_SET_NIGHT_MODE = "set_night_mode"
        const val METHOD_GET_STATUS = "get_status"
        const val EXTRA_IS_NIGHT = "isNight"
    }
}
