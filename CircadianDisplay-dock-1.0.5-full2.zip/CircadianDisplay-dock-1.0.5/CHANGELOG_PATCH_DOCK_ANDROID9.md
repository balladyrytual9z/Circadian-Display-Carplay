# Patch: Dock 2.0 + Android 9 (API 28) IPC hardening

## Changes

### `DockStateProvider.kt`
- Trusted callers expanded: `pl.dock.widget` **and** `pl.dock.launcher` (Dock 2.0).
- Primary identity check via `getCallingPackage()` (stable on API 28); UID fallback kept.
- Untrusted control methods throw `SecurityException` (Dock must catch) instead of only returning a soft fail bundle.
- Safer null/context handling around `SchedulerWorker.triggerNow`.
- Malformed `isNight` extras handled without crashing the Binder call.

### `DockNightModeReceiver.kt`
- Defensive parse of `isNight` extra.
- `pendingResult.finish()` guarded; uses `applicationContext` for WorkManager.
- Documented hardening for force-stop / malformed Intents from Dock.

### `docs_DOCK_INTEGRATION.md`
- Updated contract for Dock 2.0 packages and Android 9 guidance (async bridge, try/catch, tests).
- Correct ContentResolver methods/authority for CircadianBridge examples.

### `AndroidManifest.xml`
- Unchanged structure already correct (exported provider + non-exported receiver).

## Apply

Copy the two Kotlin files over the existing paths in the Circadian Display tree, and replace `docs_DOCK_INTEGRATION.md` at the repo root.
